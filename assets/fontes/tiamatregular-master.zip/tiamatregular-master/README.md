# TiamatRegular

TiamatReglar font as distributed in web pages

Used for D&D 5e

If you want to get started quickly, just take the three .OTF files. Enjoy!


www.derczynski.com/dnd
